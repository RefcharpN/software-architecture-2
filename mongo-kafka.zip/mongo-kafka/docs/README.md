# MongoDB Kafka Connector

For more information on the official MongoDB Kafka Connector, see the [official documentation]( https://docs.mongodb.com/kafka-connector/current/).
