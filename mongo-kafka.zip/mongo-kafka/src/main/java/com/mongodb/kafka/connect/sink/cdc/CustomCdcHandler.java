package com.mongodb.kafka.connect.sink.cdc;

import java.util.Optional;

import org.bson.*;

import com.mongodb.client.model.*;

import com.mongodb.kafka.connect.sink.MongoSinkTopicConfig;
import com.mongodb.kafka.connect.sink.converter.SinkDocument;

public class CustomCdcHandler extends CdcHandler {

  public CustomCdcHandler(MongoSinkTopicConfig config) {
    super(config);
  }

  @Override
  public Optional<WriteModel<BsonDocument>> handle(SinkDocument doc) {
    BsonDocument valueDoc =
        doc.getValueDoc().orElseThrow(() -> new IllegalArgumentException("valueDoc is required"));

    BsonDocument instituteDoc = new BsonDocument();

    BsonDocument topDoc =
        new BsonDocument().append("name", new BsonString(valueDoc.getString("name").getValue()));

    BsonArray cafedrasArray = new BsonArray();
    BsonDocument cafedrasDoc =
        new BsonDocument()
            .append(
                "name",
                new BsonString(valueDoc.getDocument("kafedra").getString("name").getValue()));

    BsonArray specialnostsArray = new BsonArray();
    BsonDocument specialnostsDoc =
        new BsonDocument()
            .append(
                "name",
                new BsonString(valueDoc.getDocument("specialnosts").getString("name").getValue()));

    BsonArray disciplinesArray = new BsonArray();
    BsonDocument disciplinesDoc =
        new BsonDocument()
            .append(
                "name",
                new BsonString(valueDoc.getDocument("disciplines").getString("name").getValue()))
            .append(
                "technical",
                new BsonBoolean(
                    valueDoc.getDocument("disciplines").getBoolean("technical").getValue()));

    disciplinesArray.add(disciplinesDoc);
    specialnostsDoc.append("disciplines", disciplinesArray);
    specialnostsArray.add(specialnostsDoc);

    cafedrasDoc.append("specialnosts", specialnostsArray);
    cafedrasArray.add(cafedrasDoc);

    topDoc.append("kafedra", cafedrasArray);
    instituteDoc.append("institute", topDoc);

    ReplaceOneModel<BsonDocument> replaceOneModel =
        new ReplaceOneModel<>(
            Filters.eq("id", new BsonObjectId(valueDoc.getObjectId("id").getValue())),
            instituteDoc);

    return Optional.of(replaceOneModel);
  }
}
