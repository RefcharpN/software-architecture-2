package com.mongodb.kafka.connect.sink.cdc;

import java.util.*;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.kafka.connect.sink.cdc.debezium.OperationType;
import org.apache.kafka.connect.errors.DataException;
import org.bson.BsonDocument;
import org.bson.BsonValue;

import com.mongodb.client.model.InsertOneModel;
import com.mongodb.client.model.WriteModel;

import com.mongodb.kafka.connect.sink.MongoSinkTopicConfig;
import com.mongodb.kafka.connect.sink.converter.SinkDocument;
import org.bson.Document;

public class CustomCdcHandler extends CdcHandler {



  public CustomCdcHandler(final MongoSinkTopicConfig config) {
    super(config);
  }

  @Override
  public Optional<WriteModel<BsonDocument>> handle(SinkDocument doc) {
    // Получаем BsonDocument из SinkDocument

    MongoClient mongoClient = MongoClients.create("mongodb://root:2517Pass!Part@mongo:27017/");
    MongoDatabase database = mongoClient.getDatabase("db_mirea");
    MongoCollection<Document> collection = database.getCollection("smelkin");

    BsonDocument valueDoc = doc.getValueDoc().orElse(null);
    if (valueDoc == null) {
      return Optional.empty();
    }

    System.out.println("\n\nТопик- " + getConfig().getTopic() + " документ- " + valueDoc +  " операция- "  +  "\n\n");

    WriteModel<BsonDocument> writeModel = null;
    if(getConfig().getTopic().equals("mirea.public.institute"))
    {
      writeModel = new InsertOneModel<>(valueDoc);
    }
    else if(getConfig().getTopic().equals("mirea.public.kafedra"))
    {

      Document foundDocument = collection.find(Filters.eq("id", valueDoc.get("institute_id"))).first();

      if (foundDocument != null) {
        List<Document> kafedras = foundDocument.getList("kafedras", Document.class);

        // Если массив kafedras отсутствует, создаем его
        if (kafedras == null) {
          kafedras = new ArrayList<>();
          foundDocument.put("kafedras", kafedras);
        }
        // Добавляем valueDoc в массив kafedras
        kafedras.add(new Document(valueDoc));
        // Обновляем найденный документ, добавляя обновленный массив kafedras
        collection.updateOne(
                Filters.eq("id", valueDoc.get("institute_id")),
                Updates.set("kafedras", kafedras)
        );
      } else {
        System.out.println("Объект не найден.");
      }

      mongoClient.close();
      return Optional.empty();
    }
    else if(getConfig().getTopic().equals("mirea.public.specialnost"))
    {
      writeModel = new InsertOneModel<>(valueDoc);
    }
    else if(getConfig().getTopic().equals("mirea.public.disciplines"))
    {

      writeModel = new InsertOneModel<>(valueDoc);

    }

    return Optional.of(writeModel);
  }
}
