package com.mongodb.kafka.connect.sink.cdc;

import java.util.*;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.*;
import com.mongodb.kafka.connect.sink.cdc.debezium.OperationType;
import org.apache.kafka.connect.errors.DataException;
import org.bson.BsonDocument;
import org.bson.BsonValue;

import com.mongodb.kafka.connect.sink.MongoSinkTopicConfig;
import com.mongodb.kafka.connect.sink.converter.SinkDocument;
import org.bson.Document;

public class CustomCdcHandler extends CdcHandler {



  public CustomCdcHandler(final MongoSinkTopicConfig config) {
    super(config);
  }

  @Override
  public Optional<WriteModel<BsonDocument>> handle(SinkDocument doc) {
    MongoClient mongoClient = MongoClients.create("mongodb://root:2517Pass!Part@mongo:27017/");
    MongoDatabase database = mongoClient.getDatabase("db_mirea");
    MongoCollection<Document> collection = database.getCollection("smelkin");

    BsonDocument valueDoc = doc.getValueDoc().orElse(null);
    if (valueDoc == null) {
      return Optional.empty();
    }

    System.out.println("\nначало cdc\nТопик- " + getConfig().getTopic() + " документ- " + valueDoc +  " операция- "  +  "\n\n");

    WriteModel<BsonDocument> writeModel = null;
    if(getConfig().getTopic().equals("mirea.public.institute"))
    {
      writeModel = new InsertOneModel<>(valueDoc);
    }
    else if(getConfig().getTopic().equals("mirea.public.kafedra"))
    {
      Document foundDocument = collection.find(Filters.eq("id", valueDoc.get("institute_id"))).first();
      if (foundDocument != null) {
        List<Document> kafedras = foundDocument.getList("kafedras", Document.class);
        if (kafedras == null) {
          kafedras = new ArrayList<>();
          foundDocument.put("kafedras", kafedras);
        }
        kafedras.add(new Document(valueDoc));
        collection.updateOne(
                Filters.eq("id", valueDoc.get("institute_id")),
                Updates.set("kafedras", kafedras)
        );
      } else {
        System.out.println("Объект не найден.");
      }
      mongoClient.close();
      return Optional.empty();
    }
    else if(getConfig().getTopic().equals("mirea.public.specialnost"))
    {
      Document foundDocument = collection.find(
              Filters.elemMatch("kafedras", Filters.eq("id", valueDoc.get("kafedra_id")))
      ).first();
      if (foundDocument != null) {
        // Получаем массив kafedras из найденного документа
        List<Document> kafedras = foundDocument.getList("kafedras", Document.class);
        // Проверяем, есть ли хотя бы один элемент в массиве kafedras
        if (!kafedras.isEmpty()) {
          // Проходим по всем элементам массива kafedras
          for (Document kafedra : kafedras) {
            // Проверяем, совпадает ли поле "id" с полем "kafedra_id" из valueDoc
            if (kafedra.get("id").equals(valueDoc.get("kafedra_id").asInt32().getValue())) {
              // Получаем или создаем массив specialnosts в найденном элементе массива kafedras
              List<Document> specialnosts = kafedra.getList("specialnosts", Document.class);
              if (specialnosts == null) {
                specialnosts = new ArrayList<>();
                kafedra.put("specialnosts", specialnosts);
              }
              // Добавляем valueDoc в массив specialnosts
              specialnosts.add(new Document(valueDoc));
              // Обновляем найденный документ, добавляя обновленный массив kafedras
              collection.updateOne(
                      Filters.eq("_id", foundDocument.getObjectId("_id")), // Предполагаем, что _id является уникальным идентификатором документа
                      Updates.addToSet("kafedras.$[elem].specialnosts", new Document(valueDoc)), // Добавляем элемент specialnosts к найденному элементу массива kafedras
                      new UpdateOptions().arrayFilters(Arrays.asList(Filters.eq("elem.id", valueDoc.get("kafedra_id")))) // Указываем фильтр, чтобы найти нужный элемент массива kafedras
              );
              // Если элемент найден и обновлен, выходим из цикла
              break;
            }
          }
        } else {
          System.out.println("Элемент массива kafedras не найден.");
        }
    } else {
      System.out.println("Объект не найден.");
    }
      return Optional.empty();
    }
    else if(getConfig().getTopic().equals("mirea.public.disciplines"))
    {
      Document foundDocument = collection.find(
              Filters.elemMatch("kafedras", Filters.elemMatch("specialnosts", Filters.eq("id", valueDoc.get("spec_id"))))
      ).first();

      if (foundDocument != null) {
        System.out.println("Найденный объект: " + foundDocument.toJson());

        // Получаем массив kafedras из найденного документа
        List<Document> kafedras = foundDocument.getList("kafedras", Document.class);
        // Проверяем, есть ли хотя бы один элемент в массиве kafedras
        if (!kafedras.isEmpty()) {
          // Проходим по всем элементам массива kafedras
          for (Document kafedra : kafedras) {
            // Проверяем, совпадает ли поле "id" с полем "specialnost_id" из valueDoc
            List<Document> specialnosts = kafedra.getList("specialnosts", Document.class);
            if (specialnosts != null) {
              // Проходим по всем элементам массива specialnosts
              for (Document specialnost : specialnosts) {
                if (specialnost.get("id").equals(valueDoc.get("spec_id").asInt32().getValue())) {
                  // Получаем или создаем массив disciplines в найденном элементе массива specialnosts
                  List<Document> disciplines = specialnost.getList("disciplines", Document.class);
                  if (disciplines == null) {
                    disciplines = new ArrayList<>();
                    specialnost.put("disciplines", disciplines);
                  }
                  // Добавляем valueDoc в массив disciplines
                  disciplines.add(new Document(valueDoc));

                  // Обновляем найденный документ, добавляя обновленный массив kafedras
                  collection.updateOne(
                          Filters.eq("_id", foundDocument.getObjectId("_id")), // Предполагаем, что _id является уникальным идентификатором документа
                          Updates.set("kafedras", kafedras) // Обновляем массив kafedras в найденном документе
                  );
                  // Если элемент найден и обновлен, выходим из цикла
                  break;
                }
              }
            }
          }
        } else {
          System.out.println("Элемент массива kafedras не найден.");
        }
      } else {
        System.out.println("Объект не найден.");
      }

      return Optional.empty();
    }
    return Optional.of(writeModel);
  }
}
